<script src="<?= base_url() ?>/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url() ?>/assets/adminlte/dist/js/adminlte.min.js"></script>
</body>
</html>
