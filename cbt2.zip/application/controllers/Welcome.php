<?php
/*   ________________________________________
    |                 GarudaCBT              |
    |    https://github.com/garudacbt/cbt    |
    |________________________________________|
*/
 defined("\x42\x41\123\105\120\101\124\x48") or exit("\116\x6f\40\144\x69\x72\145\143\x74\x20\163\x63\162\x69\x70\164\x20\x61\x63\x63\145\x73\163\40\x61\x6c\x6c\157\167\x65\x64"); class Welcome extends CI_Controller { public function index() { $this->load->view("\167\x65\154\143\x6f\x6d\145\137\x6d\x65\x73\x73\141\x67\145"); } }
