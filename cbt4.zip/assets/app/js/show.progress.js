(function($) {
    showSuccessAlert = function(title, message, txtOk, txtCancel, fn) {
        'use strict';
    };
    showInfoAlert = function(msg) {
        'use strict';
    };
    showWarningAlert = function(msg) {
        'use strict';
    };
    showDangerAlert = function(msg) {
        'use strict';
    };
})(jQuery);
